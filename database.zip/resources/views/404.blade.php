@extends('layouts.app')
@section('content')
<div class="row justify-content-center mb-5">
  <img src="image/404.jpg" heigth="300" width="500px">
</div>
<h3 class="text-center font-weight-bold display-4">404 - Pagina no encontrada</h3>
@endsection
