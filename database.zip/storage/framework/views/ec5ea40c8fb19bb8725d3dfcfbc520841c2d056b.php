<?php $__env->startSection('content'); ?>
  <!-- Listado de Usuarios -->

  <br>
  <br>
  <br>
  <br>
  <h2 align="center">Panel de Administracion - Usuarios</h2>

  <br>
  <div class="row justify-content-center">
    <a href="<?php echo e(url('usuario/alta')); ?>" class="btn btn-success " role="button" aria-pressed="true">Crear Usuario</a>
  </div>
  <br>
  <br>

  <table class="table table-hover">
    <theader>
    <tr><th>ID </th><th>Nombre</th><th>Apellido</th><th>DNI</th><th>Email</th><th>Telefono</th><th>Fecha de Nacimiento</th><th>Direccion</th><th>ID Cities</th>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr data-id="<?php echo e($user->id); ?>">
        <td><?php echo e($user->id); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->lastname); ?></td>
        <td><?php echo e($user->dni); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->phone); ?></td>
        <td><?php echo e($user->date_birth); ?></td>
        <td><?php echo e($user->street); ?> N°<?php echo e($user->number); ?></td>
        <td><?php echo e($user->cities_id); ?></td>
        <td>
          <a href='<?php echo e(url('usuario')); ?>/editar/<?php echo e($user->id); ?>' title="Editar"><i class="fa fa-edit"></i></a>
          <a href='#' title="Eliminar" class="btn-delete"><i class="fa fa-times"></i></a>
        </td>

      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php echo $users->render(); ?>

  <?php echo Form::open(['url' => ['usuario', ':USERS_ID'], 'method' => 'DELETE', 'id' => 'frm_delete' ]); ?>

  <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<!--Se tenia que instalar el FORM en el Composer.json -->
<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function(){
  //Ejecuta Funciones una vez cargada en su totalidad de una Dom

    $('.btn-delete').click(function(event) {
      event.preventDefault();
      var row = $(this).parents('tr');
      var id = $(row).data('id');
      var form = $('#frm_delete');
      var action = decodeURIComponent($(form).attr('action'));
      var url = action.replace(':USERS_ID',id);
      var data = form.serialize();
      $.post(url, data, function(result) {
        console.log(result.msg);
        row.fadeOut();
      }).fail(function() {
        alert('No se pudo eliminar');
      });
    });
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>