<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">

  <div class="card" style="width: 40rem;">
    <br>
    <br>
    <br>
    <br>
    <div class="card-header" align="center"><h2>Alta Usuario</h2></div>

      <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(url('usuario')); ?>" enctype="multipart/form-data" >
          <?php echo csrf_field(); ?>


          <div class="row">

              <div class="col-12 col-md-6">
                <label for="name">Nombre:</label>
                <input class="form-control"  type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" />
              </div>

              <div class="form-group col-12 col-md-6">
                <label for="lastname">Apellido:</label>
                <input class="form-control"  type="text" name="lastname" id="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="Apellido" />
              </div>

          </div>

          <div class="row">

              <div class="col-12 col-md-6">
                <label for="dni">Dni:</label>
                <input class="form-control" min="0" type="number" name="dni" id="dni" value="<?php echo e(old('dni')); ?>" placeholder="Dni" />
              </div>

              <div class="form-group col-12 col-md-6">
                <label for="email">Email:</label>
                <input class="form-control"  type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="Email" />
              </div>

          </div>

          <div class="row">

              <div class="col-12 col-md-6">
                <label for="phone">Telefono:</label>
                <input class="form-control" min="0" type="number" name="phone" id="phone" value="<?php echo e(old('phone')); ?>" placeholder="Telefono" />
              </div>

              <div class="form-group col-12 col-md-6">
                <label for="date_birth">Fecha de Nacimiento:</label>
                <input class="form-control"  type="date" name="date_birth" id="date_birth" value="<?php echo e(old('date_birth')); ?>" placeholder="Fecha de Nacimiento" />
              </div>

          </div>

          <div class="row">

          <div class="col-12 col-md-6">
            <label for="provinces_id">Provincia</label>
            <select class="form-control" id="provinces_id" name="provinces_id" >
              <option value="">Seleccione una Provincia</option>
              <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($province->province_id); ?>"><?php echo e($province->province_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-12 col-md-6">
            <label for="cities_id">Ciudad</label>
            <select class="form-control" id="cities_id" name="cities_id" >
              <option value="">Seleccione una Ciudad</option>
              <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city->city_id); ?>"><?php echo e($city->city_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          </div>
          
          <div class="row">

              <div class="col-12 col-md-6">
                <label for="street">Calle:</label>
                <input class="form-control" type="text" name="street" id="street" value="<?php echo e(old('street')); ?>" placeholder="Calle" />
              </div>

              <div class="form-group col-12 col-md-6">
                <label for="number">Numero:</label>
                <input class="form-control" min="0" type="number" name="number" id="number" value="<?php echo e(old('number')); ?>" placeholder="Numero" />
              </div>

          </div>

        <div class="form-row mt-3">

          <div class="col">
            <button type="submit" class="btn btn-primary btn-block">Crear</button>
          </div>

          <div class="col">
            <a href="<?php echo e(url('usuario')); ?>" class="btn btn-warning btn-block">Volver</a>
          </div>

        </div>

      </form>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>