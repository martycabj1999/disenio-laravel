<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">

  <div class="card" style="width: 40rem;">
    <br>
    <br>
    <br>
    <br>
    <div class="card-header" align="center"><h2>Alta Beca</h2></div>

      <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(url('beca')); ?>" enctype="multipart/form-data" >
          <?php echo csrf_field(); ?>


          <div class="row">
              <div class="col-12 col-md-9">
                <label for="name">Nombre:</label>
                <input class="form-control"  type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" />
              </div>
          </div>

          <div class="row">
              <div class="form-group col-12 col-md-9">
                <label for="discount">Descuento:</label>
                <input class="form-control"  type="number" name="discount" id="discount" value="<?php echo e(old('discount')); ?>" placeholder="Descuento" />
              </div>
          </div>

        <div class="form-row mt-3">

          <div class="col">
            <button type="submit" class="btn btn-primary btn-block">Crear</button>
          </div>

          <div class="col">
            <a href="<?php echo e(url('usuario')); ?>" class="btn btn-warning btn-block">Volver</a>
          </div>

        </div>

      </form>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>