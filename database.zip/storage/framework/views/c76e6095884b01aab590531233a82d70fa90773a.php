<?php $__env->startSection('content'); ?>
  <!-- Listado de Becas -->

  <br>
  <br>
  <br>
  <br>
  <h2 align="center">Panel de Administracion - Servicios Complementarios</h2>

  <br>
  <div class="row justify-content-center">
    <a href="<?php echo e(url('serviciocomplementario/alta')); ?>" class="btn btn-success " role="button" aria-pressed="true">Crear Servicio Complementario</a>
  </div>
  <br>
  <br>

  <table class="table table-hover">
    <theader>
    <tr><th>ID </th><th>Nombre</th><th>Monto</th><th>Descripcion</th>
    <?php $__currentLoopData = $complementaryServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complementaryService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr data-id="<?php echo e($complementaryService->id); ?>">
        <td><?php echo e($complementaryService->id); ?></td>
        <td><?php echo e($complementaryService->name); ?></td>
        <td><?php echo e($complementaryService->amount); ?></td>
        <td><?php echo e($complementaryService->description); ?></td>
        <td>
          <a href='<?php echo e(url('serviciocomplementario')); ?>/editar/<?php echo e($complementaryService->id); ?>' title="Editar"><i class="fa fa-edit"></i></a>
          <a href='#' title="Eliminar" class="btn-delete"><i class="fa fa-times"></i></a>
        </td>

      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php echo $complementaryServices->render(); ?>

  <?php echo Form::open(['url' => ['serviciocomplementario', ':SERVICIOCOMPLEMENTARIOS_ID'], 'method' => 'DELETE', 'id' => 'frm_delete' ]); ?>

  <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<!--Se tenia que instalar el FORM en el Composer.json -->
<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function(){
  //Ejecuta Funciones una vez cargada en su totalidad de una Dom

    $('.btn-delete').click(function(event) {
      event.preventDefault();
      var row = $(this).parents('tr');
      var id = $(row).data('id');
      var form = $('#frm_delete');
      var action = decodeURIComponent($(form).attr('action'));
      var url = action.replace(':SERVICIOCOMPLEMENTARIOS_ID',id);
      var data = form.serialize();
      $.post(url, data, function(result) {
        console.log(result.msg);
        row.fadeOut();
      }).fail(function() {
        alert('No se pudo eliminar');
      });
    });
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>